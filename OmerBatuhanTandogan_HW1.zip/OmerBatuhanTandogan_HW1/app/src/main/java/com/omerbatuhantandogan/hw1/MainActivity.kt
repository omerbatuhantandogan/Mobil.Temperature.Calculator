// MainActivity.kt
package com.omerbatuhantandogan.hw1


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Spinner
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.omerbatuhantandogan.hw1.subpackage.SubPackageClass
import com.omerbatuhantandogan.hw1.ui.theme.OmerBatuhanTandogan_HW1Theme

class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize traditional Android Views
        val customSpinner = findViewById<Spinner>(R.id.customSpinner)
        val customSeekBar = findViewById<SeekBar>(R.id.customSeekBar)
        findViewById<ImageView>(R.id.imageViewMain)
        val inputButton = findViewById<Button>(R.id.inputButton)

        // Create a list of items for the Spinner
        val spinnerItems: List<String> = mutableListOf("Item 1", "Item 2", "Item 3")

        // Create a custom adapter
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, spinnerItems)
        adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item)
        customSpinner.adapter = adapter

        // Set the SeekBar listener
        customSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Update the view (e.g., ImageView) based on SeekBar progress
                // Example: imageView.setScaleX(progress / 100f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Handle when tracking starts
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // Handle when tracking stops
            }
        })

        // Set up Jetpack Compose content
        setContent {
            OmerBatuhanTandogan_HW1Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Call Composable function for your Jetpack Compose UI
                    Greeting()
                }
            }
        }

        // Set up the click listener for the inputButton
        inputButton.setOnClickListener {
            // Create an intent to start the SecondActivity
            val intent = Intent(this, activitysec::class.java)

            // Add data to the intent
            intent.putExtra("primitiveValue", 42)

            val customData = CustomData("Hello from MainActivity!", 123)
            intent.putExtra("customObject", customData)

            // Start the SecondActivity with the intent
            startActivity(intent)
        }

        // Create an object from SubPackageClass
        val subPackageObject = SubPackageClass("PrimaryValue")

        // Log the content of the object
        Log.d("MainActivity", subPackageObject.memberMethod())
    }

    class Greeting

    // ... rest of the code remains unchanged ...
}
