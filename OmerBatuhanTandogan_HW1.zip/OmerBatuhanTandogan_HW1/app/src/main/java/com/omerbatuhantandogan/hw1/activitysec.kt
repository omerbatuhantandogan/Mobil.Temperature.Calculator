package com.omerbatuhantandogan.hw1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activitysec : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activitysec)

        // Retrieve data from the intent
        val primitiveValue = intent.getIntExtra("primitiveValue", 0)

        val customData = intent.getSerializableExtra("customObject") as CustomData

        // Display the received data
        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        resultTextView.text = "Primitive Value: $primitiveValue\nCustom Object: $customData"
    }
}