// CustomData.kt
package com.omerbatuhantandogan.hw1

import java.io.Serializable

data class CustomData(val stringValue: String, val intValue: Int) : Serializable
